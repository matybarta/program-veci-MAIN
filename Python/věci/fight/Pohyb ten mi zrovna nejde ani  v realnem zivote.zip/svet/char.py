class Character:
    def __init__(self, jmeno, health, dexterity, strength, place):
        self.jmeno=jmeno
        self.health=health
        self.dexterity=dexterity
        self.strength=strength
        self.place=place